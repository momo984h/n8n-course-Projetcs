-- AlterTable
ALTER TABLE "IntegrationSession" ADD COLUMN     "context" JSONB;
